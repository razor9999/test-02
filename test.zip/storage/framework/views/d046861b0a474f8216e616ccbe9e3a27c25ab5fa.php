
<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="<?php echo e(url('adminlte/js')); ?>/bootstrap.min.js"></script>

<script src="<?php echo e(url('adminlte/js/app.min.js')); ?>"></script>

<script src="https://cdn.ckeditor.com/4.9.2/full/ckeditor.js"></script>


<script src="<?php echo e(mix('/client/js/manifest.js')); ?>" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo e(mix('/client/js/vendor.js')); ?>" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo e(mix('/client/js/app.js')); ?>" type="text/javascript" charset="utf-8"></script>

<?php echo $__env->yieldContent('javascript'); ?>
